package com.cg.lab3.service;

import java.util.List;

import com.cg.lab3.dto.RegisteredUsers;
import com.cg.lab3.exception.UserException;


public interface RegisteredUsersService {
	public int addUser(RegisteredUsers user) throws UserException;
	public List<RegisteredUsers> showAll() throws UserException;
}
