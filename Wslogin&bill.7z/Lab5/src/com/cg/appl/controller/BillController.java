package com.cg.appl.controller;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;
import com.cg.appl.service.BillServiceImpl;
import com.cg.appl.service.IBillService;


@WebServlet("*.do")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IBillService billservice;
    public BillController() {
    	billservice = new BillServiceImpl();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request, response);
	}
		protected void ProcessRequest(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			String path = request.getServletPath();
			System.out.println(path); // To check path
			BillDetails bill=new BillDetails();
			Consumer cons=new Consumer();
			IBillService service=new BillServiceImpl();
			if(path.equals("/login.do"))
			{
				String uname=request.getParameter("cname");
				String password=request.getParameter("password");				
				if((uname.equals("kuntal")) && (password.equals("123456"))){
					//System.out.println("hi");
					HttpSession session=request.getSession();
					System.out.println(session.getId());
					session.setAttribute("data", bill);
					RequestDispatcher rs = request.getRequestDispatcher("Success.html");
					rs.forward(request, response);
				}
			}
			if (path.equals("/calculate.do")) {
				String con_no=request.getParameter("cid");
				/*Pattern patt=Pattern.compile("^[1-9]{6}//d");
				Matcher mat=patt.matcher(con_no);
				if(!mat.matches()){
					String err="Should contain 6 digits";
					request.setAttribute("error", err);*/
				int lmon=Integer.parseInt(request.getParameter("lmonth"));
				int cmon=Integer.parseInt(request.getParameter("cmonth"));
				int c_no=Integer.parseInt(con_no);
				bill.setConsumer_num(c_no);
				bill.setLast_reading(lmon);
				bill.setCur_reading(cmon);
				
				try {
					bill=service.calBill(bill);
					//System.out.println(bill.getUnitconsumed());
					System.out.println(bill.getConsumer_name());
					request.setAttribute("dataname",bill.getConsumer_name());
					request.setAttribute("data1", bill.getConsumer_num());
					request.setAttribute("data2", bill.getUnitconsumed());
					request.setAttribute("data3", bill.getNetamount());
					RequestDispatcher rs = request.getRequestDispatcher("result.jsp");
					rs.forward(request, response);
					int l=service.addusers(bill);
					//System.out.println("Inserted");
				} catch (BillException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			
	}

}
