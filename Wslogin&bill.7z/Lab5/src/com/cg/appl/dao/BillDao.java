package com.cg.appl.dao;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.exceptions.BillException;

public interface BillDao {
 public BillDetails calBill(BillDetails bill) throws BillException;
 public int addusers(BillDetails bill) throws BillException;
}
