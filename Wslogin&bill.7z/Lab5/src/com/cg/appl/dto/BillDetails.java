package com.cg.appl.dto;

import java.util.Date;

public class BillDetails{

private int bill_num;
private String consumer_name;
private int consumer_num;
private int last_reading;
 private int cur_reading;
 private int unitconsumed;
 private int netamount;
 private Date bill_date;
public BillDetails(int bill_num, String consumer_name, int consumer_num, int last_reading, int cur_reading,
		int unitconsumed, int netamount, Date bill_date) {
	super();
	this.bill_num = bill_num;
	this.consumer_num = consumer_num;
	this.last_reading = last_reading;
	this.cur_reading = cur_reading;
	this.unitconsumed = unitconsumed;
	this.netamount = netamount;
	this.bill_date = bill_date;
}
public String getConsumer_name() {
	return consumer_name;
}
public void setConsumer_name(String consumer_name) {
	this.consumer_name = consumer_name;
}
public int getLast_reading() {
	return last_reading;
}
public void setLast_reading(int last_reading) {
	this.last_reading = last_reading;
}
public BillDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public int getBill_num() {
	return bill_num;
}
public void setBill_num(int bill_num) {
	this.bill_num = bill_num;
}
public int getConsumer_num() {
	return consumer_num;
}
public void setConsumer_num(int consumer_num) {
	this.consumer_num = consumer_num;
}
public int getCur_reading() {
	return cur_reading;
}
public void setCur_reading(int cur_reading) {
	this.cur_reading = cur_reading;
}
public int getUnitconsumed() {
	return unitconsumed;
}
public void setUnitconsumed(int unitconsumed) {
	this.unitconsumed = unitconsumed;
}
public int getNetamount() {
	return netamount;
}
public void setNetamount(int netamount) {
	this.netamount = netamount;
}
public Date getBill_date() {
	return bill_date;
}
public void setBill_date(Date bill_date) {
	this.bill_date = bill_date;
}
@Override
public String toString() {
	return "BillDetails [bill_num=" + bill_num + ", consumer_name="
			+ consumer_name + ", consumer_num=" + consumer_num
			+ ", last_reading=" + last_reading + ", cur_reading=" + cur_reading
			+ ", unitconsumed=" + unitconsumed + ", netamount=" + netamount
			+ ", bill_date=" + bill_date + "]";
}

 

 
}
